import tkinter as tk
import json
from tkinter import (
    Frame,
    Label,
    Entry,
    Button,
    Radiobutton,
    ttk,
    VERTICAL,
    YES,
    BOTH,
    END,
    Tk,
    W,
    StringVar,
    messagebox,
)
from Buku import *


class FrmBuku:
    def __init__(self, parent, title):
        self.parent = parent
        self.parent.geometry("450x450")
        self.parent.title(title)
        self.parent.protocol("WM_DELETE_WINDOW", self.onKeluar)
        self.ditemukan = None
        self.aturKomponen()
        self.onReload()

    def aturKomponen(self):
        mainFrame = Frame(self.parent, bd=10)
        mainFrame.pack(fill=BOTH, expand=YES)
        Label(mainFrame, text="KODEBUKU:").grid(
            row=0, column=0, sticky=W, padx=5, pady=5
        )
        Label(mainFrame, text="NAMABUKU:").grid(
            row=1, column=0, sticky=W, padx=5, pady=5
        )
        Label(mainFrame, text="STATUS:").grid(row=2, column=0, sticky=W, padx=5, pady=5)
        Label(mainFrame, text="PENULIS:").grid(
            row=3, column=0, sticky=W, padx=5, pady=5
        )
        # Textbox
        self.txtKodebuku = Entry(mainFrame)
        self.txtKodebuku.grid(row=0, column=1, padx=5, pady=5)
        self.txtKodebuku.bind("<Return>", self.onCari)  # menambahkan event Enter key
        # Textbox
        self.txtNamabuku = Entry(mainFrame)
        self.txtNamabuku.grid(row=1, column=1, padx=5, pady=5)
        # Textbox
        self.txtStatus = Entry(mainFrame)
        self.txtStatus.grid(row=2, column=1, padx=5, pady=5)
        # Textbox
        self.txtPenulis = Entry(mainFrame)
        self.txtPenulis.grid(row=3, column=1, padx=5, pady=5)
        # Button
        self.btnSimpan = Button(
            mainFrame, text="Simpan", command=self.onSimpan, width=10
        )
        self.btnSimpan.grid(row=0, column=3, padx=5, pady=5)
        self.btnClear = Button(mainFrame, text="Clear", command=self.onClear, width=10)
        self.btnClear.grid(row=1, column=3, padx=5, pady=5)
        self.btnHapus = Button(mainFrame, text="Hapus", command=self.onDelete, width=10)
        self.btnHapus.grid(row=2, column=3, padx=5, pady=5)
        # define columns
        columns = ("idbuku", "kodebuku", "namabuku", "status", "penulis")
        self.tree = ttk.Treeview(mainFrame, columns=columns, show="headings")
        # define headings
        self.tree.heading("idbuku", text="IDBUKU")
        self.tree.column("idbuku", width="70")
        self.tree.heading("kodebuku", text="KODEBUKU")
        self.tree.column("kodebuku", width="70")
        self.tree.heading("namabuku", text="NAMABUKU")
        self.tree.column("namabuku", width="100")
        self.tree.heading("status", text="STATUS")
        self.tree.column("status", width="70")
        self.tree.heading("penulis", text="PENULIS")
        self.tree.column("penulis", width="70")
        # set tree position
        self.tree.place(x=0, y=200)

    def onClear(self, event=None):
        self.txtKodebuku.delete(0, END)
        self.txtKodebuku.insert(END, "")
        self.txtNamabuku.delete(0, END)
        self.txtNamabuku.insert(END, "")
        self.txtStatus.delete(0, END)
        self.txtStatus.insert(END, "")
        self.txtPenulis.delete(0, END)
        self.txtPenulis.insert(END, "")
        self.btnSimpan.config(text="Simpan")
        self.onReload()
        self.ditemukan = False

    def onReload(self, event=None):
        # get data buku
        obj = Buku()
        result = obj.get_all()
        parsed_data = json.loads(result)
        for item in self.tree.get_children():
            self.tree.delete(item)

        for i, d in enumerate(parsed_data):
            self.tree.insert(
                "",
                i,
                text="Item {}".format(i),
                values=(
                    d["idbuku"],
                    d["kodebuku"],
                    d["namabuku"],
                    d["status"],
                    d["penulis"],
                ),
            )

    def onCari(self, event=None):
        kodebuku = self.txtKodebuku.get()
        obj = Buku()
        a = obj.get_by_kodebuku(kodebuku)
        if len(a) > 0:
            self.TampilkanData()
            self.ditemukan = True
        else:
            self.ditemukan = False
            messagebox.showinfo("showinfo", "Data Tidak Ditemukan")

    def TampilkanData(self, event=None):
        kodebuku = self.txtKodebuku.get()
        obj = Buku()
        res = obj.get_by_kodebuku(kodebuku)
        self.txtKodebuku.delete(0, END)
        self.txtKodebuku.insert(END, obj.kodebuku)
        self.txtNamabuku.delete(0, END)
        self.txtNamabuku.insert(END, obj.namabuku)
        self.txtStatus.delete(0, END)
        self.txtStatus.insert(END, obj.status)
        self.txtPenulis.delete(0, END)
        self.txtPenulis.insert(END, obj.penulis)
        self.btnSimpan.config(text="Update")

    def onSimpan(self, event=None):
        # get the data from input
        kodebuku = self.txtKodebuku.get()
        namabuku = self.txtNamabuku.get()
        status = self.txtStatus.get()
        penulis = self.txtPenulis.get()
        # create new Object
        obj = Buku()
        obj.kodebuku = kodebuku
        obj.namabuku = namabuku
        obj.status = status
        obj.penulis = penulis
        if self.ditemukan == False:
            # save the record
            res = obj.simpan()
        else:
            # update the record
            res = obj.update_by_kodebuku(kodebuku)
        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]
        # display json data into messagebox
        messagebox.showinfo("showinfo", status + ", " + msg)
        # clear the form input
        self.onClear()

    def onDelete(self, event=None):
        kodebuku = self.txtKodebuku.get()
        obj = Buku()
        obj.kodebuku = kodebuku
        if self.ditemukan == True:
            res = obj.delete_by_kodebuku(kodebuku)
        else:
            messagebox.showinfo("showinfo", "Data harus ditemukan dulu sebelum dihapus")

        # read data in json format
        data = json.loads(res)
        status = data["status"]
        msg = data["message"]

        # display json data into messagebox
        messagebox.showinfo("showinfo", status + ", " + msg)

        self.onClear()

    def onKeluar(self, event=None):
        # memberikan perintah menutup aplikasi
        self.parent.destroy()


if __name__ == "__main__":
    root2 = tk.Tk()
    aplikasi = FrmBuku(root2, "Aplikasi Data Buku")
    root2.mainloop()
