<?php

require_once 'database.php';
class Buku 
{
    private $db;
    private $table = 'buku';
    public $kodebuku = "";
    public $namabuku = "";
    public $status = "";
    public $penulis = "";
    public function __construct(MySQLDatabase $db)
    {
        $this->db = $db;
    }
    public function get_all() 
    {
        $query = "SELECT * FROM $this->table";
        $result_set = $this->db->query($query);
        return $result_set;
    }
    public function get_by_id(int $id)
    {
        $query = "SELECT * FROM $this->table WHERE id = $id";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function get_by_kodebuku(int $kodebuku)
    {
        $query = "SELECT * FROM $this->table WHERE kodebuku = $kodebuku";
        $result_set = $this->db->query($query);   
        return $result_set;
    }
    public function insert(): int
    {
        $query = "INSERT INTO $this->table (`kodebuku`,`namabuku`,`status`,`penulis`) VALUES ('$this->kodebuku','$this->namabuku','$this->status','$this->penulis')";
        $this->db->query($query);
        return $this->db->insert_id();
    }
    public function update(int $id): int
    {
        $query = "UPDATE $this->table SET kodebuku = '$this->kodebuku', namabuku = '$this->namabuku', status = '$this->status', penulis = '$this->penulis' 
        WHERE idbuku = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function update_by_kodebuku($kodebuku): int
    {
        $query = "UPDATE $this->table SET kodebuku = '$this->kodebuku', namabuku = '$this->namabuku', status = '$this->status', penulis = '$this->penulis' 
        WHERE kodebuku = $kodebuku";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete(int $id): int
    {
        $query = "DELETE FROM $this->table WHERE idbuku = $id";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
    public function delete_by_kodebuku($kodebuku): int
    {
        $query = "DELETE FROM $this->table WHERE kodebuku = $kodebuku";
        $this->db->query($query);
        return $this->db->affected_rows();
    }
}
?>
